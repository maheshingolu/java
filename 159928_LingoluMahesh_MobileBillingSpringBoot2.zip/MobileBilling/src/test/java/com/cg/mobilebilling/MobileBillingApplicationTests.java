package com.cg.mobilebilling;
import static org.assertj.core.api.Assertions.assertThat;
import java.util.ArrayList;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;
import com.cg.mobilebilling.beans.Address;
import com.cg.mobilebilling.beans.Customer;
import com.cg.mobilebilling.beans.Plan;
import com.cg.mobilebilling.beans.PostpaidAccount;
import com.cg.mobilebilling.boot.MobileBillingApplication;
import com.cg.mobilebilling.daoservices.CustomerDAOServices;
import com.cg.mobilebilling.daoservices.PlanDAOServices;
import com.cg.mobilebilling.daoservices.PostpaidDAOServices;
import com.cg.mobilebilling.exceptions.BillingServicesDownException;
import com.cg.mobilebilling.exceptions.CustomerDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.PlanDetailsNotFoundException;
import com.cg.mobilebilling.services.BillingServices;
@RunWith(SpringRunner.class)
@SpringBootTest(classes=MobileBillingApplication.class)
public class MobileBillingApplicationTests {
	@MockBean
	private  CustomerDAOServices customerDAO;
	@MockBean
	private PlanDAOServices planDAO;
	@MockBean
	private PostpaidDAOServices postpaidDAO;
	@Autowired
	private BillingServices billingServices;
	@Test
	public void acceptCustomerDetailsTest() throws CustomerDetailsNotFoundException, BillingServicesDownException {
		Customer customer = new Customer(111,"Mahesh", "Lingolu", "lingolu@gmail.com", "12/06/1997", new Address(505211, "pune", "Maharastra"));
		Mockito.when(customerDAO.save(customer)).thenReturn(customer);
		assertThat(billingServices.acceptCustomerDetails(customer)).isEqualTo(customer);	
	}
	@Test
	public void getAllCustomerDetailsTest() throws BillingServicesDownException {
		Customer customer1= new Customer(111,"Supratik", "Barigala", "shravan@gmail.com", "21/07/1997", new Address(505211, "pune", "Maharastra"));
		Customer customer2= new Customer(222,"Kaushal", "Abhinav", "abhinav@gmail.com", "21/07/1996", new Address(505211, "pune", "Maharastra"));
		ArrayList<Customer> list = new ArrayList<>();
		list.add(customer1);
		list.add(customer2);
		Mockito.when(customerDAO.findAll()).thenReturn(list);
		assertThat(billingServices.getAllCustomerDetails()).isEqualTo(list);	
	}
	@Test(expected =CustomerDetailsNotFoundException.class)
	public void invalidCustomerOpenPostpaidMobileAccountTest() throws PlanDetailsNotFoundException, CustomerDetailsNotFoundException, BillingServicesDownException {
		billingServices.openPostpaidMobileAccount(110,111);
	}
	@Test
	public void getCustomerDetailsTest() throws CustomerDetailsNotFoundException, BillingServicesDownException {
		Customer customer = new Customer(121,"Shravan", "Marutha", "shravan@gmail.com", "21/07/1997", new Address(505211, "pune", "Maharastra"));
		Mockito.doReturn(customer).when(customerDAO.findById(121).get());
		assertThat(billingServices.getCustomerDetails(111)).isEqualTo(customer);

	}
	@Test(expected =PlanDetailsNotFoundException.class)
	public void invalidPlanOpenPostpaidMobileAccountTest() throws PlanDetailsNotFoundException, CustomerDetailsNotFoundException, BillingServicesDownException {
		Customer customer1= new Customer(120,"Shravan", "Marutha", "shravan@gmail.com", "21/07/1997", new Address(505211, "pune", "Maharastra"));
		Mockito.doReturn(customer1).when(billingServices.getCustomerDetails(120));
		billingServices.openPostpaidMobileAccount(111,11);
	}
	@Test
	public void openPostpaidMobileAccountTest() throws CustomerDetailsNotFoundException, PlanDetailsNotFoundException, BillingServicesDownException {
		Customer customer= new Customer(151,"Shravan", "Marutha", "shravan@gmail.com", "21/07/1997", new Address(505211, "pune", "Maharastra"));
		Plan plan = new Plan(1,499,100,100,50,50,1000,0.10f,0.20f,0.05f,0.07f,0.03f,"pune","plan101");
		PostpaidAccount postpaid = new PostpaidAccount(9550537838l, plan, customer);
		Mockito.when(customerDAO.findById(151).orElseThrow(()->new CustomerDetailsNotFoundException())).thenReturn(customer);
		Mockito.when(planDAO.findById(1).orElseThrow(()->new PlanDetailsNotFoundException())).thenReturn(plan);
		Mockito.when(postpaidDAO.save(postpaid)).thenReturn(postpaid);
		assertThat(billingServices.openPostpaidMobileAccount(111, 1)).isEqualTo(9550537838l);
	}
}
