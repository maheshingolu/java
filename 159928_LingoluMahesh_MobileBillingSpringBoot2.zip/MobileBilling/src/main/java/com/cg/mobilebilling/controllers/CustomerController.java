package com.cg.mobilebilling.controllers;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import com.cg.mobilebilling.beans.Bill;
import com.cg.mobilebilling.beans.Customer;
import com.cg.mobilebilling.beans.Plan;
import com.cg.mobilebilling.beans.PostpaidAccount;
import com.cg.mobilebilling.exceptions.BillDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.BillingServicesDownException;
import com.cg.mobilebilling.exceptions.CustomerDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.InvalidBillMonthException;
import com.cg.mobilebilling.exceptions.PlanDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.PostpaidAccountNotFoundException;
import com.cg.mobilebilling.services.BillingServices;
@Controller
public class CustomerController {
	@Autowired
	BillingServices billingServices;
	@RequestMapping("/customerRegistration")
	public ModelAndView acceptCustomerDetails(@ ModelAttribute Customer customer) {
		try {
			customer=billingServices.acceptCustomerDetails(customer);
			return new ModelAndView("customerRegistrationSuccessPage","customer",customer);
		} catch (BillingServicesDownException e) {
			return new ModelAndView("registerCustomerPage","error",e.getMessage());
		}
	}
	@RequestMapping("/postpaidAccount")
	public ModelAndView openPostpaidMobileAccount(@RequestParam int customerID,@RequestParam int planID) {
		try {
			long mobileNumber=billingServices.openPostpaidMobileAccount(customerID, planID);
			return new ModelAndView("PostpaidAccountSuccessPage","mobileNumber",mobileNumber);
		} catch (PlanDetailsNotFoundException|CustomerDetailsNotFoundException|BillingServicesDownException e) {
			return new ModelAndView("createPostpaidAccountPage","error",e.getMessage());
		}
	}
	@RequestMapping("/getAllPlanDetails")
	public ModelAndView getPlanAllDetails()  {
		try {
			List<Plan>plans=billingServices.getPlanAllDetails();
			return new ModelAndView("getAllPlanDetailsPage","plans",plans);
		} catch (BillingServicesDownException e) {
			return new ModelAndView("getAllPlanDetailsPage","error",e.getMessage());
		}
	}
	@RequestMapping("/mobileBillGeneration")
	public ModelAndView generateMonthlyMobileBill(@RequestParam int customerID,@RequestParam long mobileNo,@RequestParam String billMonth,@RequestParam int noOfLocalSMS,
			@RequestParam int noOfStdSMS,@RequestParam int noOfLocalCalls,@RequestParam int noOfStdCalls,@RequestParam int internetDataUsageUnits)  {
		try {
			Bill bill=billingServices.generateMonthlyMobileBill(customerID, mobileNo, billMonth, noOfLocalSMS, noOfStdSMS, noOfLocalCalls, noOfStdCalls, internetDataUsageUnits);
			return new ModelAndView("mobileBillPage","bill",bill);
		} catch (CustomerDetailsNotFoundException|PostpaidAccountNotFoundException|InvalidBillMonthException|BillingServicesDownException|PlanDetailsNotFoundException e) {
			return new ModelAndView("generateMobileBillPage","error",e.getMessage());
		}  
	}
	@RequestMapping("/getCustomer")
	public ModelAndView getCustomerDetails(@RequestParam int customerID)  {
		try {
			Customer customer=billingServices.getCustomerDetails(customerID);
			return new ModelAndView("customerDetailsPage","customer",customer);
		} catch (CustomerDetailsNotFoundException|BillingServicesDownException e) {
			return new ModelAndView("getCustomerDetailsPage","error",e.getMessage());
		} 
	}
	@RequestMapping("/postpaidAccountDetails")
	public ModelAndView getpostpaidAccountDetails(@RequestParam int customerID,@RequestParam long mobileNo)  {
		PostpaidAccount postpaid;
		try {
			postpaid = billingServices.getPostPaidAccountDetails(customerID, mobileNo);
			return new ModelAndView("postpaidAccountDetailsPage","postpaid",postpaid);
		} catch (CustomerDetailsNotFoundException | PostpaidAccountNotFoundException | BillingServicesDownException e) {
			return new ModelAndView("getPostpaidAccountDetails","error",e.getMessage());
		}
	}
	@RequestMapping("/getAllCustomerDetails")
	public ModelAndView getAllCustomerDetails()  {
		List<Customer> customers;
		try {
			customers = billingServices.getAllCustomerDetails();
			return new ModelAndView("getAllCustomerDetailsPage","customers",customers);
		} catch (BillingServicesDownException e) {
			return new ModelAndView("getAllCustomerDetails","error",e.getMessage());
		}
	}
	@RequestMapping("/customerAllPostpaidAccountDetails")
	public ModelAndView getCustomerAllPostpaidAccountDetails(@RequestParam int customerID) throws BillingServicesDownException, PlanDetailsNotFoundException, CustomerDetailsNotFoundException {
		List<PostpaidAccount>postpaids=billingServices.getCustomerAllPostpaidAccountsDetails(customerID);
		return new ModelAndView("customerAllPostpaidAccountDetailsPage","postpaids",postpaids);
	}
	@RequestMapping("/mobileBillDetails")
	public ModelAndView getmobileBillDetails(@RequestParam int customerID,@RequestParam long mobileNo,@RequestParam String billMonth) throws BillingServicesDownException, PlanDetailsNotFoundException, CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException, BillDetailsNotFoundException {
		Bill bill=billingServices.getMobileBillDetails(customerID, mobileNo, billMonth);
		return new ModelAndView("mobileBillDetailsPage","bill",bill);
	}
	@RequestMapping("/getAllBillDetails")
	public ModelAndView getmobileAllBillDetails(@RequestParam int customerID,@RequestParam long mobileNo) throws BillingServicesDownException, PlanDetailsNotFoundException, CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException, BillDetailsNotFoundException {
		List <Bill>bills=billingServices.getCustomerPostPaidAccountAllBillDetails(customerID, mobileNo);
		return new ModelAndView("mobileAllBillDetailsPage","bills",bills);
	}
	@RequestMapping("/changePlanDetails")
	public ModelAndView changePlanDetails(@RequestParam int customerID,@RequestParam long mobileNo, @RequestParam int planID) throws BillingServicesDownException, PlanDetailsNotFoundException, CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException, BillDetailsNotFoundException {
		boolean status=billingServices.changePlan(customerID, mobileNo, planID);
		if(status)
			return new ModelAndView("planChangeSuccessPage");
		else
			return new ModelAndView("changePlanPage");
	}
	@RequestMapping("/postpaidAccountPlanDetails")
	public ModelAndView getpostpaidAccountPlanDetails(@RequestParam int customerID,@RequestParam long mobileNo) throws BillingServicesDownException, PlanDetailsNotFoundException, CustomerDetailsNotFoundException, PostpaidAccountNotFoundException {
		Plan plan=billingServices.getCustomerPostPaidAccountPlanDetails(customerID, mobileNo);
		return new ModelAndView("postpaidAccountPlanDetailsPage","plan",plan);
	}
	@RequestMapping("/customerDeletion")
	public ModelAndView deleteCustomerDetails(@RequestParam int customerID) {
		try {
			boolean status= billingServices.deleteCustomer(customerID);
			return new ModelAndView("deletionSuccessPage");
		} catch (BillingServicesDownException | CustomerDetailsNotFoundException e) {
			return new ModelAndView("deleteCustomerPage","error",e.getMessage());
		}	
	}
}
